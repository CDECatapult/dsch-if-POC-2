"""
.. include:: ../README.md

.. include:: ../config_aidi_guide.md
"""  # noqa: D212, D415

import warnings

# Suppress all warnings
warnings.filterwarnings("ignore")
