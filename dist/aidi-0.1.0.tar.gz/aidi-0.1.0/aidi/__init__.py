"""
.. include:: ../README.md

.. include:: ../config_aidi_guide.md
"""