"""Package entry point."""

from .aidi import main

main()
